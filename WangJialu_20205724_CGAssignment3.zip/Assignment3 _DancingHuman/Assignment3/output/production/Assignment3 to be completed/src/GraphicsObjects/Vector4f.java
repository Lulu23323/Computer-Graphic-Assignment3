package GraphicsObjects;



public class Vector4f {

	public float x=0;
	public float y=0;
	public float z=0;
	public float a=0;

	//This is a default constructor
	public Vector4f() 
	{  
		x = 0.0f;
		y = 0.0f;
		z = 0.0f;
		a = 0.0f;
	}


	public Vector4f(float x, float y, float z,float a) 
	{ 
		this.x = x;
		this.y = y;
		this.z = z;
		this.a = a;
	}

	//implement Vector plus a Vector
	//Vector plus vector gives you a new vector, and the function gives
	// you the coordinates of the new vector algebraically, and geometrically,
	// the new vector can be obtained by the parallelogram rule or the triangle rule
	public Vector4f PlusVector(Vector4f Additonal) 
	{
		Vector4f result = new Vector4f(0.0f, 0.0f, 0.0f,0.0f);
		result.x = this.x + Additonal.x;
		result.y = this.y + Additonal.y;
		result.z = this.z + Additonal.z;
		return result;
	}

	//implement Vector minus a Vector
	//Vector is presupposed, a vector can be found here using algebraic
	// method, geometric, parallelogram rule can be applied to solve:
	// two vector translation to public starting point, the two sides
	// of a parallelogram as vectors, and the results by the end of the
	// vector reduction to decrease was the end of the vector
	// (parallelogram rule only applies to two non-zero non collinear vectors add and subtract
	public Vector4f MinusVector(Vector4f Minus) 
	{

		Vector4f result = new Vector4f(0.0f, 0.0f, 0.0f,0.0f);
		result.x = this.x - Minus.x;
		result.y = this.y - Minus.y;
		result.z = this.z - Minus.z;
		return result;
	}

	//implement Vector plus a Point
	//When you add a vector to a point, you take the point along the
	// vector, you move the magnitude of the vector, and you get an endpoint
	public Point4f PlusPoint(Point4f Additonal) 
	{

		Point4f result = new Point4f(0.0f,0.0f,0.0f,0.0f);
		result.x = this.x + Additonal.x;
		result.y = this.y + Additonal.y;
		result.z = this.z + Additonal.z;
		return result;
	} 
	//Do not implement Vector minus a Point as it is undefined 

	//Implement a Vector * Scalar
	//Scalar multiplication is a fundamental operation defined by vector Spaces in linear algebra. In the usual concept of
	// geometry, the magnitude of a vector is multiplied without changing its orientation by scalar multiplication of
	// Euclidean vectors of positive real numbers.
	public Vector4f byScalar(float scale )
	{
		this.x = this.x * scale;
		this.y = this.y * scale;
		this.z = this.z * scale;
		return this;
	}

	//implement returning the negative of a  Vector
	//The opposite of a vector is when you leave the length of the vector unchanged,
	// but the direction is reversed. So numerically everything is going to be the
	// opposite of what it was before
	public Vector4f  NegateVector()
	{

		this.x = this.x * -1;
		this.y = this.y * -1;
		this.z = this.z * -1;
		return this;
	}
	//implement getting the length of a Vector
	//We use the law of cosines to find the magnitude of the vector which is
	// the length of the vector
	public float length()
	{
	    return (float) Math.sqrt(x*x + y*y + z*z+ a*a);
	}
	
	//Just to avoid confusion here is getting the Normal  of a Vector  
	public Vector4f Normal()
	{
		float LengthOfTheVector=  this.length();
		return this.byScalar(1.0f/ LengthOfTheVector); 
	} 
	
	//implement getting the dot product of Vector.Vector
	//implement getting the dot product of Vector.Vector
	//This method gives you the answer to the dot product of the vectors, the dot product
	// of two vectors, the sum of the corresponding bits of the two vectors, the dot product is a scalar.

	public float dot(Vector4f v)
	{
		return ( this.x*v.x + this.y*v.y + this.z*v.z+ this.a*v.a);
	}
	
	// Implemented this for you to avoid confusion 
	// as we will not normally  be using 4 float vector  
	public Vector4f cross(Vector4f v)  
	{ 
    float u0 = (this.y*v.z - z*v.y);
    float u1 = (z*v.x - x*v.z);
    float u2 = (x*v.y - y*v.x);
    float u3 = 0; //ignoring this for now  
    return new Vector4f(u0,u1,u2,u3);
	}
 
}
	 
	   

/*

										MMMM                                        
										MMMMMM                                      
 										MM MMMM                                    
 										MMI  MMMM                                  
 										MMM    MMMM                                
 										MMM      MMMM                              
  										MM        MMMMM                           
  										MMM         MMMMM                         
  										MMM           OMMMM                       
   										MM             .MMMM                     
MMMMMMMMMMMMMMM                        MMM              .MMMM                   
MM   IMMMMMMMMMMMMMMMMMMMMMMMM         MMM                 MMMM                 
MM                  ~MMMMMMMMMMMMMMMMMMMMM                   MMMM               
MM                                  OMMMMM                     MMMMM            
MM                                                               MMMMM          
MM                                                                 MMMMM        
MM                                                                   ~MMMM      
MM                                                                     =MMMM    
MM                                                                        MMMM  
MM                                                                       MMMMMM 
MM                                                                     MMMMMMMM 
MM                                                                  :MMMMMMMM   
MM                                                                MMMMMMMMM     
MM                                                              MMMMMMMMM       
MM                             ,MMMMMMMMMM                    MMMMMMMMM         
MM              IMMMMMMMMMMMMMMMMMMMMMMMMM                  MMMMMMMM            
MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM               ZMMMMMMMM              
MMMMMMMMMMMMMMMMMMMMMMMMMMMMM          MM$             MMMMMMMMM                
MMMMMMMMMMMMMM                       MMM            MMMMMMMMM                  
  									MMM          MMMMMMMM                     
  									MM~       IMMMMMMMM                       
  									MM      DMMMMMMMM                         
 								MMM    MMMMMMMMM                           
 								MMD  MMMMMMMM                              
								MMM MMMMMMMM                                
								MMMMMMMMMM                                  
								MMMMMMMM                                    
  								MMMM                                      
  								MM                                        
                             GlassGiant.com */