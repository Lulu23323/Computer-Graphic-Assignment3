package objects3D;

import GraphicsObjects.Point4f;
import GraphicsObjects.Vector4f;
import org.lwjgl.opengl.GL11;

import static java.lang.Math.*;

public class Sphere {


	public Sphere() {

	}
	// Implement using notes and examine Tetrahedron to aid in the coding  look at lecture  7 , 7b and 8
	// 7b should be your primary source, we will cover more about circles in later lectures to understand why the code works
	public void DrawSphere(float radius,float nSlices,float nSegments) {
		GL11.glBegin(GL11.GL_QUADS);//Enable opengl's QUADS drawing method

		//Calculate the spacing between the longitude and latitude lines of the sphere
		float inctheta = (float) ((2.0f*PI)/nSlices);
		float incphi = (float) (PI/nSegments);


		//The two loops, one loop longitude and one loop latitude,
		// calculate theta and phi values for each location to be drawn.
		// According to these two values, all points on the sphere under
		// the set interval can be traversed. Taking this point as the
		// starting point, four points on a quadrilateral on the sphere
		// can be inferred clockwise, so as to draw the quadrilateral.
		for(float theta = (float) -PI; theta<PI; theta+=inctheta) {
			for(float phi = (float) (-(PI/2.0f)); phi<(PI/2.0f); phi+=incphi) {

				float nextTheta = theta + inctheta;
				float nextPhi = phi + incphi;

				float z = (float) (radius * sin(phi));
				float nextZ = (float) (radius * sin(nextPhi));

				float x1 = (float) (radius * cos(phi) * cos(theta));
				float x2 = (float) (radius * cos(nextPhi) * cos(theta));
				float x3 = (float) (radius * cos(phi) * cos(nextTheta));
				float x4 = (float) (radius * cos(nextPhi) * cos(nextTheta));

				float y1 = (float) (radius * cos(phi) * sin(theta));
				float y2 = (float) (radius * cos(nextPhi) * sin(theta));
				float y3 = (float) (radius * cos(phi) * sin(nextTheta));
				float y4 = (float) (radius * cos(nextPhi) * sin(nextTheta));

				//Note that the normal vector of each point should be set to ensure the smooth surface of the sphere
				GL11.glNormal3f(x1,y1,z);
				GL11.glVertex3f(x1,y1,z);

				GL11.glNormal3f(x2,y2,nextZ);
				GL11.glVertex3f(x2,y2,nextZ);

				GL11.glNormal3f(x4,y4,nextZ);
				GL11.glVertex3f(x4,y4,nextZ);

				GL11.glNormal3f(x3,y3,z);
				GL11.glVertex3f(x3,y3,z);


			}
		}GL11.glEnd();
	}
}

 