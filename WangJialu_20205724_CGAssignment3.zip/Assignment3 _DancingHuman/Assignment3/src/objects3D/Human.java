package objects3D;

import org.lwjgl.opengl.GL11;
import GraphicsObjects.Point4f;
import GraphicsObjects.Utils;
import GraphicsObjects.Vector4f;
import org.newdawn.slick.Color;
import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.opengl.TextureLoader;
import org.newdawn.slick.util.ResourceLoader;

import java.io.IOException;

import static java.lang.Math.*;

public class Human {

	// basic colours
	static float black[] = { 0.0f, 0.0f, 0.0f, 1.0f };
	static float white[] = { 1.0f, 1.0f, 1.0f, 1.0f };

	static float grey[] = { 0.5f, 0.5f, 0.5f, 1.0f };
	static float spot[] = { 0.1f, 0.1f, 0.1f, 0.5f };

	// primary colours
	static float red[] = { 1.0f, 0.0f, 0.0f, 1.0f };
	static float green[] = { 0.0f, 1.0f, 0.0f, 1.0f };
	static float blue[] = { 0.0f, 0.0f, 1.0f, 1.0f };

	// secondary colours
	static float yellow[] = { 1.0f, 1.0f, 0.0f, 1.0f };
	static float magenta[] = { 1.0f, 0.0f, 1.0f, 1.0f };
	static float cyan[] = { 0.0f, 1.0f, 1.0f, 1.0f };

	// other colours
	static float orange[] = { 1.0f, 0.5f, 0.0f, 1.0f, 1.0f };
	static float brown[] = { 0.5f, 0.25f, 0.0f, 1.0f, 1.0f };
	static float dkgreen[] = { 0.0f, 0.5f, 0.0f, 1.0f, 1.0f };
	static float pink[] = { 1.0f, 0.6f, 0.6f, 1.0f, 1.0f };

	
	public Human() {

	}
	
	// Implement using notes  in Animation lecture
	//Added parameters to the method to make it easy to add head, hair, skin and clothing textures
	public void DrawHuman(float delta,boolean GoodAnimation, Texture headTexture, Texture hearTexture, Texture skinTexture,Texture clothTexture) {
		float theta = (float) (delta * 2 * Math.PI);
		float thetaRid ;//The degree of theta, It's used to determine position and Angle
		float LimbRotation;
		if (GoodAnimation) {
			LimbRotation = (float) cos(theta) * 45;//Calculate the degree of theta
			thetaRid = (float) ((theta * 180) / PI);
		} else {
			LimbRotation = 0;
			thetaRid=0;
		}

		//Construct spheres, cylinders and material spheres
		Sphere sphere = new Sphere();
		Cylinder cylinder = new Cylinder();
		TexSphere texSphere = new TexSphere();


		GL11.glPushMatrix();

		{
			GL11.glTranslatef(0.0f, (float) abs(sin(theta-90))+0.5f, 0.0f);//Position your hips so that they jump over time
			sphere.DrawSphere(0.5f, 32, 32);

			//  chest
			GL11.glColor3f(green[0], green[1], green[2]);
			GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(green));
			GL11.glPushMatrix();
			{
				//Change the position of the chest relative to the crotch
				GL11.glTranslatef(0.0f, 0.5f, 0.0f);
				Color.white.bind();//Set the texture for the rib cage section
				GL11.glEnable(GL11.GL_TEXTURE_2D);
				GL11.glTexParameteri( GL11.GL_TEXTURE_2D,  GL11.GL_TEXTURE_MAG_FILTER,  GL11.GL_NEAREST);
				clothTexture.bind();
				texSphere.DrawTexSphere(0.5f, 32, 32, clothTexture);
//				sphere.DrawSphere(0.5f, 32, 32);


				// neck
				GL11.glColor3f(orange[0], orange[1], orange[2]);
				GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(orange));
				GL11.glPushMatrix();
				{
					//The previous component translates and rotates the origin into place
					//Draw the neck
					GL11.glTranslatef(0.0f, 0.0f, 0.0f);
					GL11.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
					//                    GL11.glRotatef(45.0f,0.0f,1.0f,0.0f);
					cylinder.DrawCylinder(0.15f, 0.7f, 32);


					// head

					GL11.glColor3f(red[0], red[1], red[2]);
					GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(red));
					GL11.glPushMatrix();
					{
						//The previous component translates and rotates the origin into place
						//Draw the head
						GL11.glTranslatef(0.0f, 0.0f, 1.0f);
						GL11.glRotatef(-thetaRid, 0.0f, 0.0f, 1.0f);
						//Add facial material to the head, drawing out the expression and hair
						Color.white.bind();
						GL11.glEnable(GL11.GL_TEXTURE_2D);
						GL11.glTexParameteri( GL11.GL_TEXTURE_2D,  GL11.GL_TEXTURE_MAG_FILTER,  GL11.GL_NEAREST);
						headTexture.bind();
						texSphere.DrawTexSphere(0.5f, 32, 32, headTexture);

						//hear
						GL11.glColor3f(black[0], black[1], black[2]);
						GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(black));
						GL11.glPushMatrix();
						{
							//The previous component translates and rotates the origin into place
							//Draw the hear
							GL11.glTranslatef(-0.3f, 0.3f, 0.5f);
							//Add texture to your hair
							Color.white.bind();
							GL11.glEnable(GL11.GL_TEXTURE_2D);
							GL11.glTexParameteri( GL11.GL_TEXTURE_2D,  GL11.GL_TEXTURE_MAG_FILTER,  GL11.GL_NEAREST);
							hearTexture.bind();
							texSphere.DrawTexSphere(0.2f, 32, 32, hearTexture);
//							sphere.DrawSphere(0.2f, 32, 32);
							GL11.glPopMatrix();
						}

						GL11.glPopMatrix();
					}
					GL11.glPopMatrix();


					// right shoulder
					GL11.glColor3f(blue[0], blue[1], blue[2]);
					GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(blue));
					GL11.glPushMatrix();
					{
						//Rotate your shoulders around your chest over time so that the front of your
						// body is always facing in the direction of walking
						GL11.glTranslatef((float) (0.6 * cos(theta)), 0.3f, (float) (0.6 * sin(theta)));

						Color.white.bind();
						GL11.glEnable(GL11.GL_TEXTURE_2D);
						GL11.glTexParameteri( GL11.GL_TEXTURE_2D,  GL11.GL_TEXTURE_MAG_FILTER,  GL11.GL_NEAREST);
						skinTexture.bind();
						texSphere.DrawTexSphere(0.25f, 32, 32, skinTexture);
//						sphere.DrawSphere(0.25f, 32, 32);


						// right arm
						GL11.glColor3f(orange[0], orange[1], orange[2]);
						GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(orange));
						GL11.glPushMatrix();
						{
							//Rotate the arm around the joint over time to achieve a swinging arm effect
							GL11.glTranslatef(0.0f, 0.0f, 0.0f);
							GL11.glRotatef(-thetaRid, 0.0f, 1.0f, 0.0f);
							GL11.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);


							GL11.glRotatef(LimbRotation, 1.0f, 0.0f, 0.0f);
							//   GL11.glRotatef(27.5f,0.0f,1.0f,0.0f);
							cylinder.DrawCylinder(0.15f, 0.7f, 32);


							// right elbow
							GL11.glColor3f(blue[0], blue[1], blue[2]);
							GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(blue));
							GL11.glPushMatrix();
							{
								GL11.glTranslatef(0.0f, 0.0f, 0.75f);
								//Apply skin texture to elbows
								Color.white.bind();
								GL11.glEnable(GL11.GL_TEXTURE_2D);
								GL11.glTexParameteri( GL11.GL_TEXTURE_2D,  GL11.GL_TEXTURE_MAG_FILTER,  GL11.GL_NEAREST);
								skinTexture.bind();
								texSphere.DrawTexSphere(0.2f, 32, 32, skinTexture);
//								sphere.DrawSphere(0.2f, 32, 32);

								//right forearm
								GL11.glColor3f(orange[0], orange[1], orange[2]);
								GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(orange));
								GL11.glPushMatrix();
								{
									//Set the forearm to swing over time and then set the forearm at a 90 degree Angle relative to the upper arm
									GL11.glTranslatef(0.0f, 0.0f, 0.0f);
									GL11.glRotatef(-thetaRid, 0.0f, 1.0f, 0.0f);
									GL11.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
//		                                GL11.glRotatef(90.0f,0.0f,1.0f,0.0f);
									cylinder.DrawCylinder(0.1f, 0.7f, 32);

									// right hand
									GL11.glColor3f(blue[0], blue[1], blue[2]);
									GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(blue));
									GL11.glPushMatrix();
									{
										GL11.glTranslatef(0.0f, 0.0f, 0.75f);
										//Add a skin texture to the arm
										Color.white.bind();
										GL11.glEnable(GL11.GL_TEXTURE_2D);
										GL11.glTexParameteri( GL11.GL_TEXTURE_2D,  GL11.GL_TEXTURE_MAG_FILTER,  GL11.GL_NEAREST);
										skinTexture.bind();
										texSphere.DrawTexSphere(0.2f, 32, 32, skinTexture);
//										sphere.DrawSphere(0.2f, 32, 32);

									}
									GL11.glPopMatrix();
								}
								GL11.glPopMatrix();
							}
							GL11.glPopMatrix();
						}
						GL11.glPopMatrix();
					}
					GL11.glPopMatrix();


					//The logic of the left hand is the same as the right hand but some of the parameters are negative
					// left shoulder
					GL11.glColor3f(blue[0], blue[1], blue[2]);
					GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(blue));
					GL11.glPushMatrix();
					{
						GL11.glTranslatef((float) (-0.6 * cos(theta)), 0.3f, (float) (-0.6 * sin(theta)));

						Color.white.bind();
						GL11.glEnable(GL11.GL_TEXTURE_2D);
						GL11.glTexParameteri( GL11.GL_TEXTURE_2D,  GL11.GL_TEXTURE_MAG_FILTER,  GL11.GL_NEAREST);
						skinTexture.bind();
						texSphere.DrawTexSphere(0.25f, 32, 32, skinTexture);
//						sphere.DrawSphere(0.25f, 32, 32);


						// left arm
						GL11.glColor3f(orange[0], orange[1], orange[2]);
						GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(orange));
						GL11.glPushMatrix();
						{
							GL11.glTranslatef(0.0f, 0.0f, 0.0f);
							GL11.glRotatef(-thetaRid, 0.0f, 1.0f, 0.0f);
							GL11.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);


							GL11.glRotatef(-LimbRotation, 1.0f, 0.0f, 0.0f);
//						    GL11.glRotatef(27.5f,0.0f,1.0f,0.0f);
							cylinder.DrawCylinder(0.15f, 0.7f, 32);


							// left elbow
							GL11.glColor3f(blue[0], blue[1], blue[2]);
							GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(blue));
							GL11.glPushMatrix();
							{
								GL11.glTranslatef(0.0f, 0.0f, 0.75f);
								Color.white.bind();
								GL11.glEnable(GL11.GL_TEXTURE_2D);
								GL11.glTexParameteri( GL11.GL_TEXTURE_2D,  GL11.GL_TEXTURE_MAG_FILTER,  GL11.GL_NEAREST);
								skinTexture.bind();
								texSphere.DrawTexSphere(0.2f, 32, 32, skinTexture);
//								sphere.DrawSphere(0.2f, 32, 32);

								//left forearm
								GL11.glColor3f(orange[0], orange[1], orange[2]);
								GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(orange));
								GL11.glPushMatrix();
								{
									GL11.glTranslatef(0.0f, 0.0f, 0.0f);
									GL11.glRotatef(-thetaRid, 0.0f, 1.0f, 0.0f);
									GL11.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
									//   GL11.glRotatef(90.0f,0.0f,1.0f,0.0f);
									cylinder.DrawCylinder(0.1f, 0.7f, 32);

									// left hand
									GL11.glColor3f(blue[0], blue[1], blue[2]);
									GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(blue));
									GL11.glPushMatrix();
									{
										GL11.glTranslatef(0.0f, 0.0f, 0.75f);
										Color.white.bind();
										GL11.glEnable(GL11.GL_TEXTURE_2D);
										GL11.glTexParameteri( GL11.GL_TEXTURE_2D,  GL11.GL_TEXTURE_MAG_FILTER,  GL11.GL_NEAREST);
										skinTexture.bind();
										texSphere.DrawTexSphere(0.2f, 32, 32, skinTexture);
//										sphere.DrawSphere(0.2f, 32, 32);

									}
									GL11.glPopMatrix();
								}
								GL11.glPopMatrix();
							}
							GL11.glPopMatrix();
						}
						GL11.glPopMatrix();
					}
					GL11.glPopMatrix();
					//chest
				}
				GL11.glPopMatrix();

				// pelvis


				// left hip
				GL11.glColor3f(blue[0], blue[1], blue[2]);
				GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(blue));
				GL11.glPushMatrix();
				{
					//Enter the component where the hip resides
//		                GL11.glTranslatef(-0.5f,-0.2f,0.0f);
					//Rotate the hip around the body over time so that the figure is always facing the direction of travel
					GL11.glTranslatef((float) (-0.6 * cos(theta)), -0.3f, (float) (-0.6 * sin(theta)));
					sphere.DrawSphere(0.25f, 32, 32);


					// left high leg
					GL11.glColor3f(orange[0], orange[1], orange[2]);
					GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(orange));
					GL11.glPushMatrix();
					{
						//Set translation and rotation to allow the legs to swing over time, creating a walking motion
						GL11.glTranslatef(0.0f, 0.0f, 0.0f);
						GL11.glRotatef(-thetaRid, 0.0f, 1.0f, 0.0f);
						GL11.glRotatef(0.0f, 0.0f, 0.0f, 0.0f);


						GL11.glRotatef((LimbRotation / 2) + 90, 1.0f, 0.0f, 0.0f);
						cylinder.DrawCylinder(0.15f, 0.7f, 32);


						// left knee
						GL11.glColor3f(blue[0], blue[1], blue[2]);
						GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(blue));
						GL11.glPushMatrix();
						{
							GL11.glTranslatef(0.0f, 0.0f, 0.75f);
							GL11.glRotatef(0.0f, 0.0f, 0.0f, 0.0f);

							Color.white.bind();
							GL11.glEnable(GL11.GL_TEXTURE_2D);
							GL11.glTexParameteri( GL11.GL_TEXTURE_2D,  GL11.GL_TEXTURE_MAG_FILTER,  GL11.GL_NEAREST);
							skinTexture.bind();
							texSphere.DrawTexSphere(0.25f, 32, 32, skinTexture);
//							sphere.DrawSphere(0.25f, 32, 32);

							//Set the rotation so that the calf can rotate over time as part of the jump
							GL11.glRotatef((float) (90*abs(cos(theta-45))),1.0f,0.0f,0.0f);

							//left low leg
							GL11.glColor3f(orange[0], orange[1], orange[2]);
							GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(orange));
							GL11.glPushMatrix();
							{
								GL11.glTranslatef(0.0f, 0.0f, 0.0f);
//		                            GL11.glRotatef(90.0f,1.0f,0.0f,0.0f);
//		                            GL11.glRotatef(0.0f,0.0f,0.0f,0.0f);
								cylinder.DrawCylinder(0.15f, 0.7f, 32);

								// left foot
								GL11.glColor3f(blue[0], blue[1], blue[2]);
								GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(blue));
								GL11.glPushMatrix();
								{
									GL11.glTranslatef(0.0f, 0.0f, 0.75f);
									Color.white.bind();
									GL11.glEnable(GL11.GL_TEXTURE_2D);
									GL11.glTexParameteri( GL11.GL_TEXTURE_2D,  GL11.GL_TEXTURE_MAG_FILTER,  GL11.GL_NEAREST);
									skinTexture.bind();
									texSphere.DrawTexSphere(0.3f, 32, 32, skinTexture);
//									sphere.DrawSphere(0.3f, 32, 32);

								}
								GL11.glPopMatrix();
							}
							GL11.glPopMatrix();
						}
						GL11.glPopMatrix();
					}
					GL11.glPopMatrix();
				}
				GL11.glPopMatrix();

				// pelvis


				//The logic is the same as that of the left leg, but some parameters are negative and rotation of the calf is eliminated
				// right hip
				GL11.glColor3f(blue[0], blue[1], blue[2]);
				GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(blue));
				GL11.glPushMatrix();
				{
//				 GL11.glTranslatef(0.5f,-0.2f,0.0f);
					GL11.glTranslatef((float) (0.6 * cos(theta)), -0.3f, (float) (0.6 * sin(theta)));

					sphere.DrawSphere(0.25f, 32, 32);


					// right high leg
					GL11.glColor3f(orange[0], orange[1], orange[2]);
					GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(orange));
					GL11.glPushMatrix();
					{
						GL11.glTranslatef(0.0f, 0.0f, 0.0f);
						GL11.glRotatef(-thetaRid, 0.0f, 1.0f, 0.0f);
						GL11.glRotatef(0.0f, 0.0f, 0.0f, 0.0f);


						GL11.glRotatef((-LimbRotation / 2) + 360, 1.0f, 0.0f, 0.0f);
						GL11.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
						cylinder.DrawCylinder(0.15f, 0.7f, 32);


						// right knee
						GL11.glColor3f(blue[0], blue[1], blue[2]);
						GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(blue));
						GL11.glPushMatrix();
						{
							GL11.glTranslatef(0.0f, 0.0f, 0.75f);
							GL11.glRotatef(0.0f, 0.0f, 0.0f, 0.0f);

							Color.white.bind();
							GL11.glEnable(GL11.GL_TEXTURE_2D);
							GL11.glTexParameteri( GL11.GL_TEXTURE_2D,  GL11.GL_TEXTURE_MAG_FILTER,  GL11.GL_NEAREST);
							skinTexture.bind();
							texSphere.DrawTexSphere(0.25f, 32, 32, skinTexture);
//							sphere.DrawSphere(0.25f, 32, 32);

							//right low leg
							GL11.glColor3f(orange[0], orange[1], orange[2]);
							GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(orange));
							GL11.glPushMatrix();
							{
								GL11.glTranslatef(0.0f, 0.0f, 0.0f);
//							  GL11.glRotatef(-90.0f,1.0f,0.0f,0.0f);
								//  GL11.glRotatef(0.0f,0.0f,0.0f,0.0f);
								cylinder.DrawCylinder(0.15f, 0.7f, 32);

								// right foot
								GL11.glColor3f(blue[0], blue[1], blue[2]);
								GL11.glMaterial(GL11.GL_FRONT, GL11.GL_AMBIENT_AND_DIFFUSE, Utils.ConvertForGL(blue));
								GL11.glPushMatrix();
								{
									GL11.glTranslatef(0.0f, 0.0f, 0.75f);

									Color.white.bind();
									GL11.glEnable(GL11.GL_TEXTURE_2D);
									GL11.glTexParameteri( GL11.GL_TEXTURE_2D,  GL11.GL_TEXTURE_MAG_FILTER,  GL11.GL_NEAREST);
									skinTexture.bind();
									texSphere.DrawTexSphere(0.3f, 32, 32, skinTexture);
//									sphere.DrawSphere(0.3f, 32, 32);

								}
								GL11.glPopMatrix();
							}
							GL11.glPopMatrix();
						}
						GL11.glPopMatrix();
					}
					GL11.glPopMatrix();
				}
				GL11.glPopMatrix();

			}
			GL11.glPopMatrix();

		}
	}
}


 
	/*
	 
	 
}

	*/
	 